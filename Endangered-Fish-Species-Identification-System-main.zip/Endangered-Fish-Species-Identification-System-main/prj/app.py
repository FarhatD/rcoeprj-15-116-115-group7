from flask import Flask,render_template,request,redirect,send_from_directory,url_for
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
import os
import saved_model
from flask import jsonify

app=Flask(__name__)
app.config['UPLOAD_DIRECTORY']='static/uploads/'
app.config['MAX_CONTENT_LNGTH']=16*1024*1024 #16MB
app.config['ALLOWED_EXTENSIONS']=['.jpg','.jpeg','.png']


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    try:
        file=request.files['file']
        extension=os.path.splitext(file.filename)[1]
        if file:
            if extension not in app.config['ALLOWED_EXTENSIONS']:
                return 'File is not an image'
            file.save(os.path.join(
                app.config['UPLOAD_DIRECTORY'],
                secure_filename(file.filename)
                ))
            filename = secure_filename(file.filename)
            return render_template('index.html', filename=filename,paath=str(app.config['UPLOAD_DIRECTORY']))
        #     imgt=os.path.join(app.config['UPLOAD_DIRECTORY'],
        #         secure_filename(file.filename)
        #         )
        # print(imgt)
    except RequestEntityTooLarge:
        return 'File is larger than 16MB mit'
    return redirect('/')

@app.route('/display_image/<filename>')
def display_image(filename):
    print("display_image filename" + filename)
    print(url_for('static', filename='uploads/'+filename))
    return redirect(url_for('static', filename='uploads/'+filename),code=301)

@app.route('/get')
def get_predicted_fish():
    img_link=request.args.get('msg')
    fish_spc=saved_model.output(img_link)
    return jsonify(name=str(fish_spc[0]),descp=str(fish_spc[1]),sc_name=str(fish_spc[2]),com_name=str(fish_spc[3]),place=str(fish_spc[4]),iucn=str(fish_spc[5]))


if __name__=="__main__":
    app.run(debug=True)