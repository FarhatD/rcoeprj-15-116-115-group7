window.onload=function() {
    document.getElementById("spes_name").style.visibility="hidden";
    var btn=document.getElementById("get_res");
    var main=document.getElementById("tab");

btn.addEventListener('click',message)
function message(f) {
    f.preventDefault();
    console.log(path+gp);
    FishPredict(path+gp)

 
}
function FishPredict(file_path) {
    $.get("/get", {msg: file_path}).done(function(data) {
        console.log(data.name);
        document.getElementById("spes_name").style.visibility="visible";
        document.getElementById("spes_name").innerText=data.name;
        console.log(data.sc_name," ",data.iucn);
        output=` <div id="tab">
        <table id="list">
            <tr>
                <td class="opt">Fish Name</td>
                <td>${data.name}</td>
            </tr>
            <tr>
                <td class="opt">Description</td>
                <td>${data.descp}</td>
            </tr>
            <tr>
                <td class="opt">Scientific Name</td>
                <td>${data.sc_name}</td>
            </tr>
            <tr>
                <td class="opt">Common Name</td>
                <td >${data.com_name}</td>
            </tr>
            <tr>
                <td class="opt">Place Found</td>
                <td>${data.place}</td>
            </tr>
            <tr>
                <td class="opt">IUCN Status</td>
                <td>${data.iucn}</td>
            </tr>
        </table>
        </div>`;
        main.insertAdjacentHTML("beforeend",output);
    })
}
}