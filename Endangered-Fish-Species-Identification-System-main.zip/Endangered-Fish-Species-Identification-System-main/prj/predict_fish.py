import os
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow
import scipy.io
import scipy.misc
import numpy as np
import pandas as pd
import cv2
import tensorflow as tf
from ultralytics import YOLO
from yad2k.models.keras_yolo import yolo_head, yolo_boxes_to_corners, preprocess_true_boxes, yolo_loss

model_path = os.path.join('.', 'runs', 'detect', 'train4', 'weights', 'last.pt')
model = YOLO(model_path)
image="C:/Users/DELL/Desktop/mini projects/Major project/project/prj/Final_dataset/Alepes djedaba_1.jpg"
# image="Alepes djedaba_1.jpg"
# image = np.asarray(image)
img = cv2.imread(image)
model=YOLO(model_path)
results = model(img)
print(results)
print(model.predict(image))
# for result in results[0].boxes.data:
#         x1, y1, x2, y2, score, class_id = result
#         print(x1," ",y1)
#         print(x2," ",y2)
#         print(score)
#         print(class_id)

