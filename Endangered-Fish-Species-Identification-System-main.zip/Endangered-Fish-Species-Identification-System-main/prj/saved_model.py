from keras.models import load_model
from keras.layers import Input, Lambda, Dense, Flatten
from keras.models import Model
from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
# from keras.preprocessing import image
from keras_preprocessing.image import load_img,img_to_array
from keras.models import load_model
from keras.models import Sequential
from sklearn.model_selection import train_test_split
from glob import glob
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os.path
import csv

IMAGE_SIZE = [224, 224]
# train_directory='../input/100-bird-species/train'
# test_directory='../input/100-bird-species/test'
# val_directory='../input/100-bird-species/valid'

image_dir=Path('C:/Users/DELL/Desktop/mini projects/Major project/project/prj/Final_dataset')
filepath=list(image_dir.glob(r'**/*.jpg'))
# print(len(filepath))
filepath=filepath+list(image_dir.glob(r'**/*.jfif'))
# print(len(filepath))
filepath=filepath+list(image_dir.glob(r'**/*.png'))
# print(len(filepath))
filepath=filepath+list(image_dir.glob(r'**/*.jpeg'))
# for i in filepath:
#     print(i)
labl = list(map(lambda x: os.path.split(x)[1], filepath))
ki=['1','2','3','4','5','6']
labels=list()
for i in labl:
    i=i.split(".")[0]
    if "_" in i:
        i=i.replace("_","")
    i = ''.join([j for j in i if not j.isdigit()])
    labels.append(i)
# for i in labels:
#     print(i)

#Create csv file of filepath and its species
filepath = pd.Series(filepath, name='Filepath').astype(str)
labels = pd.Series(labels, name='Label')
image_df = pd.concat([filepath, labels], axis=1)
train_df,test_df=train_test_split(image_df,train_size=0.8,shuffle=True,random_state=1)
from keras.preprocessing.image import ImageDataGenerator
train_datagen = ImageDataGenerator(rescale = 1./255,
                                   shear_range = 0.2,
                                   zoom_range = 0.2,
                                   horizontal_flip = True)

test_datagen = ImageDataGenerator(rescale = 1./255)

train_images=train_datagen.flow_from_dataframe(
    dataframe=train_df,
    x_col='Filepath',
    y_col='Label',
    target_size=(224,224),
    color_model='rgb',
    class_mode='categorical',
    batch_size=32,
    shuffle=True,
    seed=42,
    subset='training'
)
model1 = load_model('./BC2.h5',compile=False)  
lab = train_images.class_indices
lab={k:v for v,k in lab.items()}

def output(location):
    img=load_img(location,target_size=(224,224,3))
    img=img_to_array(img)
    img=img/255
    img=np.expand_dims(img,[0])
    answer=model1.predict(img)
    y_class = answer.argmax(axis=-1)
    y = " ".join(str(x) for x in y_class)
    y = int(y)
    res = lab[y]
    print(res)
    doct_set='DESCRIPTION OF FISHES.csv'
    with open(doct_set,newline='') as csvfile:
            data=csv.DictReader(csvfile)
            for rw in data:
                if rw['NAME']==res:
                    print(rw['IUCN STATUS'])
                    return res,rw['DESCRIPTION'],rw['SCIENTIFIC NAME'],rw['COMMON NAME'],rw['PLACE'],rw['IUCN STATUS']
    return res

# #img='Final_dataset/Centropyge flavipectoralis 8.jpg'
# img='C:/Users/DELL/Desktop/94441.jpg'
# # pic=load_img('C:/Users/DELL/Desktop/mini projects/Major project/project/prj/Final_dataset/Notopterus notopterus_1.jpg',target_size=(224,224,3))
# # plt.imshow(pic)
# print(output(img))